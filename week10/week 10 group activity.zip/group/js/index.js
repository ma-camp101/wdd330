import QuakesController from "./quakesController.js";

const quakeController = new QuakesController('#quakeList')
quakeController.init();
