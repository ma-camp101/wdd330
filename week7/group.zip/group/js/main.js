// import your module 
import Hikes from './hikes.js';

// create an instance of the class
const myHike = new Hikes('hikes');

myHike.showHikeList();

